#include <iostream>
using namespace std;

int longitudCadena(const char* cad) {
    int len = 0;
    while (cad[len] != '\0') {
        len++;
    }
    return len;
}

void copiarCadena(char* destino, const char* origen) {
    int i = 0;
    while (origen[i] != '\0') {
        destino[i] = origen[i];
        i++;
    }
    destino[i] = '\0';
}

void convertirMayusculas(char* cad) {
    int i = 0;
    while (cad[i] != '\0') {
        if (cad[i] >= 'a' && cad[i] <= 'z') {
            cad[i] = cad[i] - 32;
        }
        i++;
    }
}

int main() {
    char buffer[200];

    cout << "Ingrese una cadena: ";
    cin.getline(buffer, 200);

    int longitud = longitudCadena(buffer) + 1;
    char* cadena = new char[longitud];

    copiarCadena(cadena, buffer);

    convertirMayusculas(cadena);

    cout << "Cadena convertida: " << cadena << endl;

    delete[] cadena;

    return 0;
}
