#include <iostream>
using namespace std;

void eliminarRepetidos(char* cad) {
    int index = 0;

    for (int i = 0; cad[i] != '\0'; i++) {
        bool repetido = false;

        for (int j = 0; j < index; j++) {
            if (cad[i] == cad[j]) {
                repetido = true;
                break;
            }
        }

        if (!repetido) {
            cad[index] = cad[i];
            index++;
        }
    }

    cad[index] = '\0';
}

int main() {
    char cadena[200];

    cout << "Ingrese una cadena: ";
    cin.getline(cadena, 200);

    eliminarRepetidos(cadena);

    cout << "Cadena sin repetidos: " << cadena << endl;

    return 0;
}
