#include <iostream>
using namespace std;

int longitudCadena(const char* cad) {
    int len = 0;
    while (cad[len] != '\0') {
        len++;
    }
    return len;
}

int convertirNumero(const char* cad, int inicio, int n) {
    int num = 0;
    for (int i = 0; i < n; i++) {
        num = num * 10 + (cad[inicio + i] - '0');
    }
    return num;
}

int main() {
    int n;
    char buffer[200];

    cout << "Ingrese el valor de n (numero de cifras por bloque): ";
    cin >> n;

    cin.ignore();
    cout << "Ingrese una cadena de caracteres numericos: ";
    cin.getline(buffer, 200);

    int len = longitudCadena(buffer);

    int resto = len % n;
    int nuevosCeros = (resto == 0) ? 0 : (n - resto);

    int nuevaLongitud = len + nuevosCeros;

    char* cadena = new char[nuevaLongitud + 1];

    for (int i = 0; i < nuevosCeros; i++) {
        cadena[i] = '0';
    }

    for (int i = 0; i < len; i++) {
        cadena[nuevosCeros + i] = buffer[i];
    }

    cadena[nuevaLongitud] = '\0';

    int suma = 0;
    for (int i = 0; i < nuevaLongitud; i += n) {
        suma += convertirNumero(cadena, i, n);
    }

    cout << "Cadena ajustada: " << cadena << endl;
    cout << "Resultado de la suma: " << suma << endl;

    delete[] cadena;

    return 0;
}
