#include <iostream>
using namespace std;

int convertirACadenaEntero(const char* cad) {
    int numero = 0;
    int i = 0;

    while (cad[i] != '\0') {
        if (cad[i] < '0' || cad[i] > '9') {
            cout << "Error: la cadena contiene caracteres no numericos." << endl;
            return 0; 
        }
        numero = numero * 10 + (cad[i] - '0');
        i++;
    }

    return numero;
}

int main() {
    char cadena[100];

    cout << "Ingrese una cadena numerica: ";
    cin.getline(cadena, 100);

    int numero = convertirACadenaEntero(cadena);

    cout << "El numero convertido es: " << numero << endl;

    return 0;
}
