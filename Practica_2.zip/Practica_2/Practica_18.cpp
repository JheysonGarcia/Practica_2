#include <iostream>
using namespace std;

unsigned long long factorial(int n) {
    unsigned long long* f = new unsigned long long[n + 1];
    f[0] = 1;
    for (int i = 1; i <= n; i++) {
        f[i] = f[i - 1] * i;
    }
    unsigned long long resultado = f[n];
    delete[] f;
    return resultado;
}

string nPermutacion(unsigned long long n) {
    int* digitos = new int[10];
    for (int i = 0; i < 10; i++) {
        digitos[i] = i;
    }

    string resultado = "";
    n--;
    int longitud = 10;

    for (int i = 10; i > 0; i--) {
        unsigned long long fact = factorial(i - 1);
        int index = n / fact;

        resultado += to_string(digitos[index]);

        for (int j = index; j < longitud - 1; j++) {
            digitos[j] = digitos[j + 1];
        }
        longitud--;

        n %= fact;
    }

    delete[] digitos;
    return resultado;
}

int main() {
    unsigned long long n;
    cout << "Ingrese el valor de n: ";
    cin >> n;

    string perm = nPermutacion(n);

    cout << "La permutacion numero " << n << " es: " << perm << endl;

    return 0;
}
