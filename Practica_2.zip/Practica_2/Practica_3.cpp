#include <iostream>
using namespace std;

bool compararCadenas(const char* cad1, const char* cad2) {
    int i = 0;

    while (cad1[i] != '\0' && cad2[i] != '\0') {
        if (cad1[i] != cad2[i]) {
            return false;
        }
        i++;
    }

    if (cad1[i] != '\0' || cad2[i] != '\0') {
        return false;
    }

    return true;
}

int main() {
    char cadena1[100];
    char cadena2[100];

    cout << "Ingrese la primera cadena: ";
    cin.getline(cadena1, 100);

    cout << "Ingrese la segunda cadena: ";
    cin.getline(cadena2, 100);

    if (compararCadenas(cadena1, cadena2)) {
        cout << "Las cadenas son iguales." << endl;
    } else {
        cout << "Las cadenas son diferentes." << endl;
    }

    return 0;
}
