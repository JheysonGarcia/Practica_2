#include <iostream>
#include <map>      
#include <cstdlib> 
#include <ctime>  

using namespace std;

int main() {
    srand(time(0));

    map<char, int> contador;

    int cantidad = 200;
    for (int i = 0; i < cantidad; i++) {
        char letra = 'A' + (rand() % 26); 
        contador[letra]++;
    }

    cout << "Contidad de letras:\n";
    for (char c = 'A'; c <= 'Z'; c++) {
        cout << c << ": " << contador[c] << endl;
    }

    return 0;
}
