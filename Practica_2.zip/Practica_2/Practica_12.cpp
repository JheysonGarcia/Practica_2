#include <iostream>
using namespace std;

bool numeroRepetido(int* usados, int total, int valor) {
    for (int i = 0; i < total; i++) {
        if (usados[i] == valor) return true;
    }
    return false;
}

bool esCuadradoMagico(int** matriz, int n) {
    int sumaObjetivo = 0;

    for (int j = 0; j < n; j++) {
        sumaObjetivo += matriz[0][j];
    }

    for (int i = 0; i < n; i++) {
        int sumaFila = 0;
        for (int j = 0; j < n; j++) {
            sumaFila += matriz[i][j];
        }
        if (sumaFila != sumaObjetivo) return false;
    }

    for (int j = 0; j < n; j++) {
        int sumaCol = 0;
        for (int i = 0; i < n; i++) {
            sumaCol += matriz[i][j];
        }
        if (sumaCol != sumaObjetivo) return false;
    }

    int sumaDiag1 = 0;
    for (int i = 0; i < n; i++) {
        sumaDiag1 += matriz[i][i];
    }
    if (sumaDiag1 != sumaObjetivo) return false;

    int sumaDiag2 = 0;
    for (int i = 0; i < n; i++) {
        sumaDiag2 += matriz[i][n - 1 - i];
    }
    if (sumaDiag2 != sumaObjetivo) return false;

    return true;
}

int main() {
    int n;
    cout << "Ingrese el tamaño de la matriz cuadrada: ";
    cin >> n;

    int** matriz = new int*[n];
    for (int i = 0; i < n; i++) {
        matriz[i] = new int[n];
    }

    int* usados = new int[n * n];
    int usadosCount = 0;

    cout << "Ingrese los elementos de la matriz (" << n * n << " enteros):\n";
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            int valor;
            cin >> valor;

            if (numeroRepetido(usados, usadosCount, valor)) {
                cout << " Error: el numero " << valor << " ya fue ingresado. Intente de nuevo.\n";
                j--;
                continue;
            }
            usados[usadosCount++] = valor;
            matriz[i][j] = valor;
        }
    }

    cout << "\nMatriz ingresada:\n";
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << matriz[i][j] << "\t";
        }
        cout << endl;
    }

    if (esCuadradoMagico(matriz, n)) {
        cout << "\n La matriz es un cuadrado magico.\n";
    } else {
        cout << "\n La matriz NO es un cuadrado magico.\n";
    }

    for (int i = 0; i < n; i++) {
        delete[] matriz[i];
    }
    delete[] matriz;
    delete[] usados;

    return 0;
}
