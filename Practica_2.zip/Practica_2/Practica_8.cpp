#include <iostream>
using namespace std;

void separarNumeros(const char* entrada, char*& letras, char*& numeros) {
    int len = 0;
    while (entrada[len] != '\0') {
        len++;
    }

    letras = new char[len + 1];
    numeros = new char[len + 1];

    int li = 0, ni = 0;
    for (int i = 0; i < len; i++) {
        if (entrada[i] >= '0' && entrada[i] <= '9') {
            numeros[ni++] = entrada[i];
        } else {
            letras[li++] = entrada[i];
        }
    }

    letras[li] = '\0';
    numeros[ni] = '\0';
}

int main() {
    char buffer[200];
    char* letras = nullptr;
    char* numeros = nullptr;

    cout << "Ingrese una cadena: ";
    cin.getline(buffer, 200);

    separarNumeros(buffer, letras, numeros);

    cout << "Cadena sin numeros: " << letras << endl;
    cout << "Cadena de numeros: " << numeros << endl;

    delete[] letras;
    delete[] numeros;

    return 0;
}
