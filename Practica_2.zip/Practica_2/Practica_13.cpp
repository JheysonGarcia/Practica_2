#include <iostream>
using namespace std;

int contarEstrellas(int *matriz, int filas, int cols) {
    int estrellas = 0;

    for (int i = 1; i < filas - 1; i++) {
        for (int j = 1; j < cols - 1; j++) {
            int centro    = *(matriz + i * cols + j);
            int izquierda = *(matriz + i * cols + (j - 1));
            int derecha   = *(matriz + i * cols + (j + 1));
            int arriba    = *(matriz + (i - 1) * cols + j);
            int abajo     = *(matriz + (i + 1) * cols + j);

            double promedio = (centro + izquierda + derecha + arriba + abajo) / 5.0;

            if (promedio > 6) {
                estrellas++;
            }
        }
    }

    return estrellas;
}

int main() {
    int filas = 6;
    int cols = 8;

    int *imagen = new int[filas * cols]{
        0, 3, 4, 0, 0, 0, 6, 8,
        5, 13, 6, 0, 0, 0, 2, 3,
        2, 6, 2, 7, 3, 0, 10, 0,
        0, 0, 4, 15, 4, 1, 6, 0,
        0, 0, 7, 12, 6, 9, 10, 4,
        5, 0, 6, 10, 6, 4, 8, 0
    };

    int estrellas = contarEstrellas(imagen, filas, cols);

    cout << "Número de estrellas encontradas: " << estrellas << endl;

    delete[] imagen;

    return 0;
}
