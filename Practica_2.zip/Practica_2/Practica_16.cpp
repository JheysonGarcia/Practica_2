#include <iostream>
using namespace std;

unsigned long long factorial(int n) {
    unsigned long long* f = new unsigned long long[n + 1];
    f[0] = 1;

    for (int i = 1; i <= n; i++) {
        f[i] = f[i - 1] * i;
    }

    unsigned long long resultado = f[n];
    delete[] f;
    return resultado;
}

unsigned long long caminos(int n) {
    return factorial(2 * n) / (factorial(n) * factorial(n));
}

int main() {
    int n;
    cout << "Ingrese el valor de n: ";
    cin >> n;

    unsigned long long resultado = caminos(n);

    cout << "Para una malla de " << n << "x" << n << " puntos hay " 
         << resultado << " caminos." << endl;

    return 0;
}
