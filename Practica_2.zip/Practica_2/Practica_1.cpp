#include <iostream>

using namespace std;

int main() {
    int Valor_a_Pagar;
    int Valor_Pagado;
    int Valor_a_Devolver;
    int contador;

    cout << "Ingrese el valor a pagar: ";
    cin >> Valor_a_Pagar;
    cout << "Ingrese el valor que ha pagado: ";
    cin >> Valor_Pagado;

    if (Valor_Pagado >= Valor_a_Pagar) {
        Valor_a_Devolver = Valor_Pagado - Valor_a_Pagar;
        cout << "El valor a devolver es: " << Valor_a_Devolver << endl;

        contador = Valor_a_Devolver / 50000;
        cout << "Billetes de 50000: " << contador << endl;
        Valor_a_Devolver %= 50000;

        contador = Valor_a_Devolver / 20000;
        cout << "Billetes de 20000: " << contador << endl;
        Valor_a_Devolver %= 20000;

        contador = Valor_a_Devolver / 10000;
        cout << "Billetes de 10000: " << contador << endl;
        Valor_a_Devolver %= 10000;

        contador = Valor_a_Devolver / 5000;
        cout << "Billetes de 5000: " << contador << endl;
        Valor_a_Devolver %= 5000;

        contador = Valor_a_Devolver / 2000;
        cout << "Billetes de 2000: " << contador << endl;
        Valor_a_Devolver %= 2000;

        contador = Valor_a_Devolver / 1000;
        cout << "Billetes de 1000: " << contador << endl;
        Valor_a_Devolver %= 1000;

        contador = Valor_a_Devolver / 500;
        cout << "Monedas de 500: " << contador << endl;
        Valor_a_Devolver %= 500;

        contador = Valor_a_Devolver / 200;
        cout << "Monedas de 200: " << contador << endl;
        Valor_a_Devolver %= 200;

        contador = Valor_a_Devolver / 100;
        cout << "Monedas de 100: " << contador << endl;
        Valor_a_Devolver %= 100;

        contador = Valor_a_Devolver / 50;
        cout << "Monedas de 50: " << contador << endl;
        Valor_a_Devolver %= 50;

        cout << "El valor restante es: " << Valor_a_Devolver << endl;
    }
    else {
        cout << "El valor ingresado no puede ser inferior al valor a pagar: " 
             << Valor_a_Pagar << endl;
    }

    return 0;
}
