#include <iostream>
using namespace std;

char** crearSala(int filas, int asientos) {
    char** sala = new char*[filas];
    for (int i = 0; i < filas; i++) {
        sala[i] = new char[asientos];
        for (int j = 0; j < asientos; j++) {
            sala[i][j] = '-';
        }
    }
    return sala;
}
void mostrarSala(char** sala, int filas, int asientos) {
    cout << "    ";
    for (int j = 1; j <= asientos; j++) {
        if (j < 10) cout << j << "  ";
        else cout << j << " ";
    }
    cout << endl;

    for (int i = 0; i < filas; i++) {
        cout << char('A' + i) << " | ";
        for (int j = 0; j < asientos; j++) {
            cout << sala[i][j] << "  ";
        }
        cout << endl;
    }
}
void reservar(char** sala, int fila, int asiento) {
    if (sala[fila][asiento] == '-') {
        sala[fila][asiento] = '+';
        cout << "Asiento reservado exitosamente.\n";
    } else {
        cout << "El asiento ya esta ocupado.\n";
    }
}
void cancelar(char** sala, int fila, int asiento) {
    if (sala[fila][asiento] == '+') {
        sala[fila][asiento] = '-';
        cout << "Reserva cancelada exitosamente.\n";
    } else {
        cout << "El asiento ya estaba disponible.\n";
    }
}

int main() {
    const int FILAS = 15;
    const int ASIENTOS = 20;

    char** sala = crearSala(FILAS, ASIENTOS);

    int opcion;
    do {
        cout << "\n--- MENU SALA DE CINE ---\n";
        cout << "1. Mostrar sala\n";
        cout << "2. Reservar asiento\n";
        cout << "3. Cancelar reserva\n";
        cout << "0. Salir\n";
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        if (opcion == 1) {
            mostrarSala(sala, FILAS, ASIENTOS);
        } else if (opcion == 2) {
            char filaLetra;
            int asientoNum;
            cout << "Ingrese la fila (A-O): ";
            cin >> filaLetra;
            cout << "Ingrese el numero de asiento (1-20): ";
            cin >> asientoNum;

            int fila = filaLetra - 'A';
            int asiento = asientoNum - 1;

            if (fila >= 0 && fila < FILAS && asiento >= 0 && asiento < ASIENTOS) {
                reservar(sala, fila, asiento);
            } else {
                cout << "Posicion invalida.\n";
            }
        } else if (opcion == 3) {
            char filaLetra;
            int asientoNum;
            cout << "Ingrese la fila (A-O): ";
            cin >> filaLetra;
            cout << "Ingrese el numero de asiento (1-20): ";
            cin >> asientoNum;

            int fila = filaLetra - 'A';
            int asiento = asientoNum - 1;

            if (fila >= 0 && fila < FILAS && asiento >= 0 && asiento < ASIENTOS) {
                cancelar(sala, fila, asiento);
            } else {
                cout << "Posicion invalida.\n";
            }
        }

    } while (opcion != 0);

    for (int i = 0; i < FILAS; i++) {
        delete[] sala[i];
    }
    delete[] sala;

    return 0;
}
