#include <iostream>


using namespace std;


int sumaDivisores(int n) {
    if (n == 1) {
        cout << "Divisores propios de 1: ninguno (suma = 0)" << endl;
        return 0;
    }

    cout << "Divisores propios de " << n << ": ";
    int suma = 1; 
    cout << "1";

    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) {
            cout << ", " << i;
            suma += i;

            if (i != n / i && n / i != n) {
                cout << ", " << n / i;
                suma += n / i;
            }
        }
    }

    cout << " -> suma = " << suma << endl;
    return suma;
}

int main() {
    int* a = new int;
    int* b = new int;

    cout << "Ingrese el primer numero: ";
    cin >> *a;
    cout << "Ingrese el segundo numero: ";
    cin >> *b;

    int sumaA = sumaDivisores(*a);
    int sumaB = sumaDivisores(*b);

    if (sumaA == *b && sumaB == *a) {
        cout << *a << " y " << *b << " son numeros amigables." << endl;
    } else {
        cout << *a << " y " << *b << " NO son numeros amigables." << endl;
    }

    delete a;
    delete b;
    return 0;
}
