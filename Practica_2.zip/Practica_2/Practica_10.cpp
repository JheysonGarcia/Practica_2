#include <iostream>
using namespace std;

int valorRomano(char c) {
    switch (c) {
        case 'M': return 1000;
        case 'D': return 500;
        case 'C': return 100;
        case 'L': return 50;
        case 'X': return 10;
        case 'V': return 5;
        case 'I': return 1;
        default: return 0;
    }
}
int romanoAArabigo(const char* romano) {
    int total = 0;
    int i = 0;

    while (romano[i] != '\0') {
        int valorActual = valorRomano(romano[i]);
        int valorSiguiente = valorRomano(romano[i + 1]);

        if (valorActual < valorSiguiente) {
            total += (valorSiguiente - valorActual);
            i += 2;
        } else {
            total += valorActual;
            i++;
        }
    }

    return total;
}

int main() {
    char buffer[200];  

    cout << "Ingrese un numero romano en mayusculas: ";
    cin.getline(buffer, 200);

    int len = 0;
    while (buffer[len] != '\0') {
        len++;
    }

    char* numeroRomano = new char[len + 1];

    for (int i = 0; i <= len; i++) {
        numeroRomano[i] = buffer[i];
    }

    int resultado = romanoAArabigo(numeroRomano);

    cout << "El numero ingresado fue: " << numeroRomano
         << " Que corresponde a: " << resultado << endl;

    delete[] numeroRomano;

    return 0;
}
