#include <iostream>
using namespace std;

const int N = 5;

int** crearMatriz(int n) {
    int** matriz = new int*[n];
    for (int i = 0; i < n; i++) {
        matriz[i] = new int[n];
    }
    return matriz;
}
void liberarMatriz(int** matriz, int n) {
    for (int i = 0; i < n; i++) {
        delete[] matriz[i];
    }
    delete[] matriz;
}
void imprimirMatriz(int** matriz, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << matriz[i][j] << "\t";
        }
        cout << endl;
    }
    cout << endl;
}
int** rotar90(int** origen, int n) {
    int** destino = crearMatriz(n);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            destino[j][n - 1 - i] = origen[i][j];
        }
    }
    return destino;
}

int main() {
    int** matriz = crearMatriz(N);
    int valor = 1;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            matriz[i][j] = valor++;
        }
    }

    cout << "Matriz original:" << endl;
    imprimirMatriz(matriz, N);
    int** matriz90 = rotar90(matriz, N);
    cout << "Matriz rotada 90 grados:" << endl;
    imprimirMatriz(matriz90, N);
    int** matriz180 = rotar90(matriz90, N);
    cout << "Matriz rotada 180 grados:" << endl;
    imprimirMatriz(matriz180, N);
    int** matriz270 = rotar90(matriz180, N);
    cout << "Matriz rotada 270 grados:" << endl;
    imprimirMatriz(matriz270, N);
    liberarMatriz(matriz, N);
    liberarMatriz(matriz90, N);
    liberarMatriz(matriz180, N);
    liberarMatriz(matriz270, N);

    return 0;
}
