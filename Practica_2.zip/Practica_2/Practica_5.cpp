#include <iostream>

using namespace std;

void intToString(int numero, char* resultado, size_t tam) {
    if (tam == 0) return;
    int i = 0;
    bool negativo = false;
    if (numero == 0) {
        if (tam > 1) {
            resultado[0] = '0';
            resultado[1] = '\0';
        }
        return;
    }
    if (numero < 0) {
        negativo = true;
        numero = -numero;
    }
    char temp[20];
    while (numero > 0 && i < (int)tam - 1) {
        temp[i++] = (numero % 10) + '0';
        numero /= 10;
    }
    if (negativo && i < (int)tam - 1) {
        temp[i++] = '-';
    }
    int j = 0;
    while (i > 0 && j < (int)tam - 1) {
        resultado[j++] = temp[--i];
    }
    resultado[j] = '\0';
}

int main() {
    int numero;
    char cadena[20];
    cout << "Ingrese un numero entero: ";
    cin >> numero;
    intToString(numero, cadena, sizeof(cadena));
    cout << "El numero como cadena es: '" << cadena << "'" << endl;
    return 0;
}
