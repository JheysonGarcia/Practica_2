#include <iostream>
using namespace std;

bool interseccionRectangulos(int* A, int* B, int* C) {

    C[0] = max(A[0], B[0]); 
    C[1] = max(A[1], B[1]); 

    int xFinal = min(A[0] + A[2], B[0] + B[2]);
    int yFinal = min(A[1] + A[3], B[1] + B[3]);

    C[2] = xFinal - C[0]; 
    C[3] = yFinal - C[1]; 

    if (C[2] <= 0 || C[3] <= 0) {
        return false; 
    }
    return true; 
}

int main() {
    int* A = new int[4];
    int* B = new int[4];
    int* C = new int[4];

    cout << "Ingrese los datos del rectángulo A (x y ancho alto): ";
    cin >> A[0] >> A[1] >> A[2] >> A[3];

    cout << "Ingrese los datos del rectángulo B (x y ancho alto): ";
    cin >> B[0] >> B[1] >> B[2] >> B[3];

    bool hayInterseccion = interseccionRectangulos(A, B, C);

    cout << "Rectángulo A: {" << A[0] << ", " << A[1] << ", " << A[2] << ", " << A[3] << "}" << endl;
    cout << "Rectángulo B: {" << B[0] << ", " << B[1] << ", " << B[2] << ", " << B[3] << "}" << endl;

    if (hayInterseccion) {
        cout << "Intersección C: {" << C[0] << ", " << C[1] << ", " << C[2] << ", " << C[3] << "}" << endl;
    } else {
        cout << "No hay intersección entre los rectángulos." << endl;
    }

    delete[] A;
    delete[] B;
    delete[] C;

    return 0;
}
